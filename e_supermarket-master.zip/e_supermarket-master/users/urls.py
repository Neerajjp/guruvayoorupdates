from django.urls import path, re_path
from users import views


app_name = "users"

urlpatterns = [ 
    # re_path(r'^contact-us/$', views.entry_customer_message,name="entry_customer_message"),
]